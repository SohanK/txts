% Eating Habits
% Jane Doe
% March 22, 2005

# In the morning


<center>

  Right     Left     Center     Default
-------     ------ ----------   -------
     12     12        12            12
    123     123       123          123
      1     1          1             1
    456     78         910          12
	 12     12        12            12
	
Table:  Demonstration of simple table syntax.

</center>

The ziffness of dorkies must:

- Eat eggs
- Drink coffee

# In the evening

As shown here:

<img align=right src="../img/plot/plot1.png">

- z-ness has large variance [@item1; @item2].
- x is symmetric to y  [@item3, pp. 33-35]
- as predicted by theory [@item1]


# During the week

This is how we roll

rolling ![all the dat](../img/dot/dot1.png)

# Conclusion

- And the answer is...
- $f(x)=\sum_{n=0}^\infty\frac{f^{(n)}(a)}{n!}(x-a)^n$

# References
