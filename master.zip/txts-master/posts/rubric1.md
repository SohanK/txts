<h1>Cs510 Hw1 </h1>

(See also: [Homework1](hw1.html).)

<font size=1>

Date:

|Member|Last name| First name | github id | email |
|:-----|:----|:-----------|:----------|:----- |
| 1    |     |            |           |       |
| 2    |     |            |           |       |
| 3    |     |            |           |       |
| 4    |     |            |           |       |


Url of slides:  

Url of Gitgub organization:

|Tick| What  |
|:------|-------|
| |Slides exist|
| |Gitbub organization exists|
| |All team members are members of the organization |
| |All members have committed equal (ish) to the repository.|
| |The file txts/Makefile has a new name for `Out`.|
| |The text of the slides have been altered.|
| |Slides contain one modified gnuplot figure.|
| |Slides contain one modified table.|
| |Slides contain one modified equation.|
| |Slides contain one modified CSS trick.|
| |There is one slide per group member.|
| |There are other slides describing the big project.|
| |The test install passed|
| |The test configuration tools passed.|
| |The test update passed.|
| | Slides are made by catting together seperate files|

Final score: round(ticks/6); so max = 3
